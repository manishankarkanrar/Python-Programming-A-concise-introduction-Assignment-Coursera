def problem2_2(my_list):
	 alist = ["a","e","i","o","u","y"]
	 blist = ["alpha", "beta", "gamma", "delta", "epsilon", "eta", "theta"]
    print(my_list)
    print(my_list[0])
    print(my_list)
    print(my_list[3:5])
    print(my_list[0:3])
    print(my_list[3:len(my_list)])
    print(len(my_list))
    my_list.append("z")
    print(my_list)
