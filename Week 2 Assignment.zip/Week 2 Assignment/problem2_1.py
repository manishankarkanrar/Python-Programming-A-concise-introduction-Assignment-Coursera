def problem2_1():
    lis=list(range(20,30))
    print(lis[3])
    print(lis)
    for i in range(0,len(lis)):
        print(lis[i],end=" ")
