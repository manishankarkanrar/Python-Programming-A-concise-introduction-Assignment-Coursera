import random
def problem2_4():
    alist=[]
    random.seed(70)
    for i in range(0,10):
        k=30+5*random.random()
        alist.append(k)
    print(alist)
