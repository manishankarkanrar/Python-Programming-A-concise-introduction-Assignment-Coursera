def problem2_3(new):
    for i in new:
        length=len(i)
        print("%s has %d letters."%(i,length))
