import random
def problem2_5():
    """ simulates rolling a die 10 times."""
    # Setting the seed makes the randon numbers always the same
    # This is to make the auto-grader's job easier.
    random.seed(171) # don't remove when you submit for grading
    for i in range(0,10):
        each=random.randint(1,6)
        print(each)
#problem2_5()
