def problem4_1(wordlist):
	""" Takes a word list prints it, sorts it, and prints the sorted list """
	print(wordlist)
	print(sorted (wordlist,key = str.lower))
#print (problem4_1(firstline))
