def problem3_3(month,day,year):
    
    months=['January', 'February', 'March', 'April', 'May', 'June','July','August', 'September', 'October', 'November', 'December']
    
    print(str(months[month-1])+" "+str(day)+", "+str(year))
    
#problem3_3(6,17,2016)
