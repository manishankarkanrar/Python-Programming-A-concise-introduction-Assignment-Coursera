def problem3_4(month, day, year):
    
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    
    print(str(months.index(month)+1)+'/'+str(day)+'/'+str(year))

#problem3_4("July",17,2016)
