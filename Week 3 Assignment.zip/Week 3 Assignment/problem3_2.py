#nlis=[23,64,23,46,12,24]
#atup=("c","e","a","d","b")
#stri="Rumplestilskin"

def problem3_2(collection):
    for item in collection:
        print(str(item)+'\n', end='')

#problem3_2(atup)
